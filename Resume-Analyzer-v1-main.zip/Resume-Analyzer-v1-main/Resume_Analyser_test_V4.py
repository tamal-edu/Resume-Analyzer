import streamlit as st
import json
import pandas as pd
import os
from pathlib import Path
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
import PyPDF2
from langchain.prompts import PromptTemplate, ChatPromptTemplate
from langchain.output_parsers import ResponseSchema, StructuredOutputParser
import docx2txt
import tkinter as tk
from tkinter import filedialog

# Load environment variables from .env file
load_dotenv()

# Retrieve the API key from environment variables
api_key = os.getenv('OPENAI_API_KEY', 'API key not found')

# Initialize the ChatOpenAI model with the API key
llm = ChatOpenAI(
    model="gpt-4o-mini",  # Make sure to use an available model
    temperature=0.1,
    api_key=api_key
)

# Helper functions for resume parsing
def read_pdf(file_path):
    """Read and extract text from PDF files"""
    text = ""
    with open(file_path, "rb") as file:
        pdf_reader = PyPDF2.PdfReader(file)
        for page_num in range(len(pdf_reader.pages)):
            page = pdf_reader.pages[page_num]
            text += page.extract_text()
    return text

def read_docx(file_path):
    """Read and extract text from DOCX files"""
    text = docx2txt.process(file_path)
    return text

def read_text(file_path):
    """Read text from plain text files"""
    with open(file_path, 'r', encoding='utf-8') as f:
        return f.read()

def create_parser():
    """Create a structured output parser for resume data"""
    response_schemas = [
        ResponseSchema(name="name", description="Full name of the candidate"),
        ResponseSchema(name="email", description="Email address of the candidate"),
        ResponseSchema(name="phone", description="Contact phone number without country code (e.g., 8120669882)"),
        ResponseSchema(name="address", description="Physical address of the candidate"),
        ResponseSchema(name="linkedin_profile", description="LinkedIn profile URL"),
        ResponseSchema(name="job_title", description="Current or most recent job title"),
        ResponseSchema(name="department", description="Department or functional area"),
        ResponseSchema(name="location", description="Work location or preferred location"),
        ResponseSchema(name="role_summary", description="Brief summary of current or desired role"),
        ResponseSchema(name="key_responsibilities", description="List of main job responsibilities"),
        ResponseSchema(name="required_skills", description="List of required technical skills"),
        ResponseSchema(name="experience_level", description="Level of professional experience"),
        ResponseSchema(name="educational_background", description="Academic qualifications and certifications"),
        ResponseSchema(name="preferred_qualifications", description="Additional preferred qualifications"),
        ResponseSchema(name="soft_skills", description="List of interpersonal and soft skills"),
        ResponseSchema(name="relevant_exp_in_years", description="Years of relevant experience"),
        ResponseSchema(name="language", description="Languages known and proficiency levels")
    ]
    return StructuredOutputParser.from_response_schemas(response_schemas)

def create_prompt_template():
    """Create a prompt template for resume parsing"""
    template = """
    You are an expert resume parser. Extract the following details from the resume text below.
    If a detail is not found, return "Not Found".
    Please be thorough in extracting all possible information and format lists as comma-separated values.

    Resume Text: {text}

    {format_instructions}
    """
    return ChatPromptTemplate.from_template(template)

def extract_information(text):
    """Extract structured information from resume text"""
    parser = create_parser()
    prompt_template = create_prompt_template()
    prompt = prompt_template.format_messages(
        text=text,
        format_instructions=parser.get_format_instructions()
    )
    response = llm.invoke(prompt)
    return parser.parse(response.content)

def parse_resume(file_path):
    """Parse resume based on file type"""
    if file_path.suffix.lower() == ".pdf":
        text = read_pdf(file_path)
    elif file_path.suffix.lower() == ".docx":
        text = read_docx(file_path)
    elif file_path.suffix.lower() == ".txt":
        text = read_text(file_path)
    else:
        raise ValueError("Unsupported file type.")
    return extract_information(text)

def compare_resumes(job_description, manager_context, resume_data):
    """Compare resumes with job description and calculate match scores"""
    comparison_prompt = '''
    Analyze the following job requirements and candidate resumes to identify the best matches.
    
    Job Requirements:
    {}
    
    Manager's Additional Context: Prioritize the manager context and highlight it in the summary.
    {}
    
    Evaluate each candidate against these criteria:
    1. Role Summary Match (20%)
    2. Key Responsibilities Alignment (20%)
    3. Required Skills Match (25%)
    4. Experience Level Match (15%)
    5. Educational Background Match (10%)
    6. Preferred Qualifications Match (5%)
    7. Soft Skills Alignment (5%)
    
    Candidate Resumes:
    {}
    
    Provide for each candidate:
    1. A match percentage (0-100) based on the weighted criteria above # and explain what, why and how you have done so.
    2. List the percentage of each criteria mentioned above for the candidate in the summary
    3. make sure each criteria percentage sum is equal to total match_summary
    4. A brief summary of their match highlights
    5. Key strengths aligned with the role
    6. Areas needing improvement
    7. highlight manager context in match_summary
    
    Return in this JSON format:
    {{
        "candidates": [
            {{
                "name": "candidate name",
                "email": "candidate email",
                "phone": "candidate phone",
                "match_percentage": numeric_value,
                "match_summary": "summary text",
                "strengths": ["strength1", "strength2"],
                "gaps": ["gap1", "gap2"],
                "role_percentages": {{
                    "Key Responsibility 1": percentage_value,
                    "Key Responsibility 2": percentage_value
                }}
            }}
        ]
    }}
    '''.format(
        json.dumps(job_description, indent=2),
        manager_context,
        json.dumps(resume_data, indent=2)
    )
    
    response = llm.invoke(comparison_prompt)
    try:
        content = response.content
        start_idx = content.find('{')
        end_idx = content.rfind('}') + 1
        if start_idx != -1 and end_idx != -1:
            json_str = content[start_idx:end_idx]
            return json.loads(json_str)
        return {"candidates": []}
    except json.JSONDecodeError as e:
        st.error(f"Error parsing comparison results: {str(e)}")
        return {"candidates": []}

@st.cache_data
def extract_job_components(description):
    """Extract structured components from job description"""
    jd_prompt_template = """
    Extract the following information from the job description:

         "Job_Title": "",
         "Department": "",
         "Location": "",
         "Role_Summary": "",
         "Key_Responsibilties": "",
         "Required_Skills": "",
         "Experience_level": "",
         "Educational_Background": "",
         "Preferred_Qualifications": "",
         "Soft_skills": ""

    Job Description:
    {job_description}

    Return in strict JSON format. Use 'Not specified' for missing fields.
    """
    
    jd_prompt = PromptTemplate(input_variables=["job_description"], template=jd_prompt_template)
    input_messages = [{"role": "user", "content": jd_prompt.format(job_description=description)}]
    response = llm.invoke(input=input_messages)
    content = response.content.strip()
    
    if not content.startswith("{"):
        start = content.find("{")
        end = content.rfind("}") + 1
        if start != -1 and end != -1:
            content = content[start:end]
    return content


def browse_directory():
    """Create a directory browser dialog and return selected path"""
    # Suppress the tkinter window
    root = tk.Tk()
    root.withdraw()
    root.wm_attributes('-topmost', 1)
    
    # Open the directory dialog
    selected_dir = filedialog.askdirectory()
    root.destroy()
    return selected_dir if selected_dir else None

# Streamlit UI
st.set_page_config(page_title="Resume Analysis", layout="wide")
st.title("Resume Analysis")
            

# Clear button
col1, col2, col3 = st.columns([9, 1, 1])
with col3:
    if st.button("Clear"):
        
        # Additional specific clearing methods
        st.session_state.clear()  # Clear all session state
        st.rerun()  # Restart the app
        
# Job Description Analysis Section
st.header("Job Description")
uploaded_file = st.file_uploader("Upload Job Description (PDF)", type=['pdf'])

job_description = ""
job_json = {}

if uploaded_file is not None:
    if uploaded_file.type == "application/pdf":
        pdf_reader = PyPDF2.PdfReader(uploaded_file)
        job_description = "\n".join([page.extract_text() for page in pdf_reader.pages])
        
        with st.spinner("Processing job description..."):
            job_components = extract_job_components(job_description)
            
            try:
                job_json = json.loads(job_components)
                # Display job description in table format
                job_data = {
                    "Field": ["Job Title", "Department", "Location", "Role Summary", 
                             "Key Responsibilities", "Required Skills", "Experience Level",
                             "Educational Background", "Preferred Qualifications", "Soft Skills"],
                    "Details": [
                        job_json.get("Job_Title", "Not specified"),
                        job_json.get("Department", "Not specified"),
                        job_json.get("Location", "Not specified"),
                        job_json.get("Role_Summary", "Not specified"),
                        job_json.get("Key_Responsibilties", ["Not specified"]),
                        job_json.get("Required_Skills", ["Not specified"]),
                        job_json.get("Experience_level", "Not specified"),
                        job_json.get("Educational_Background", "Not specified"),
                        job_json.get("Preferred_Qualifications", ["Not specified"]),
                        job_json.get("Soft_skills", ["Not specified"])
                    ]
                }
                df = pd.DataFrame(job_data)
                st.dataframe(df, use_container_width=True,hide_index=True)
                
            except json.JSONDecodeError as e:
                st.error(f"Error parsing job description: {str(e)}")
                job_json = {}

# Manager's Context with Submit Button
st.header("Manager's Context")
manager_context = st.text_area("Enter additional context or specific requirements:")

# Track submission state in session
if 'context_submitted' not in st.session_state:
    st.session_state.context_submitted = False

# Submit Context Button
if st.button("Submit Context"):
    if manager_context.strip():
        st.session_state.context_submitted = True
        st.success("Manager's context submitted.")
    else:
        st.warning("Please enter valid context before submitting.")

# Resume Analysis Section
st.header("Resume Analysis")

# Ensure directory path exists in session state
if 'directory_path' not in st.session_state:
    st.session_state.directory_path = None

# Create columns for the browse button and path display
col1, col2 = st.columns([1, 3])

with col1:
    if st.button("Browse Resumes Directory"):
        selected_dir = browse_directory()
        if selected_dir:
            st.session_state.directory_path = selected_dir

with col2:
    if st.session_state.directory_path:
        st.text("")
    else:
        st.text("No directory selected")

# Ensure the analysis logic checks if context is submitted
if job_json and st.session_state.directory_path and st.session_state.context_submitted:
    # Resume processing logic remains unchanged...
    try:
        files = list(Path(st.session_state.directory_path).glob("*.*"))
        resume_files = [f for f in files if f.suffix.lower() in {".pdf", ".docx", ".txt"}]

        if resume_files:
            st.write(f"Found {len(resume_files)} resume(s) to process")
            if not hasattr(st.session_state, 'resume_data'):
                resume_data = []
                progress_bar = st.progress(0)

                for idx, file_path in enumerate(resume_files):
                    try:
                        with st.spinner(f"Parsing {file_path.name}..."):
                            parsed_resume = parse_resume(file_path)
                            resume_data.append(parsed_resume)
                        progress_bar.progress((idx + 1) / len(resume_files))
                    except Exception as e:
                        st.error(f"Error parsing {file_path.name}: {str(e)}")

                st.session_state.resume_data = resume_data
                print(len(resume_data))
            else:
                resume_data = st.session_state.resume_data

            if st.button("Get Matched Resumes"):
                if resume_data:
                    with st.spinner("Analyzing and matching resumes..."):
                        matches = compare_resumes(job_json, manager_context, resume_data)
                        # JSON output
                        output_json = json.dumps(matches, indent=4)
                        #st.json(matches)

                        # Saving JSON output to file
                        if st.button("Export JSON to file"):
                            with open("resume_data.json", "w") as f:
                                f.write(matches)
                            st.success("JSON data exported to resume_data.json")
                        print("matches")
                        print(len(matches))
                        if matches and "candidates" in matches:
                            st.subheader("Matched Candidates Summary")
                            summary_data = [
                                {
                                    "Name": candidate["name"],
                                    "Match %": f"{candidate['match_percentage']}%",
                                    "Email": candidate["email"],
                                    "Phone": candidate["phone"]
                                }
                                for candidate in matches["candidates"]
                            ]
                            st.dataframe(pd.DataFrame(summary_data).sort_values("Match %", ascending=False), use_container_width=True,hide_index=True)
                        
                            # Updates only in the detailed analysis section
                            st.subheader("Detailed Analysis")
                            for candidate in sorted(matches["candidates"], 
                                                    key=lambda x: x['match_percentage'], 
                                                    reverse=True):
                                with st.expander(f"🔍 {candidate['name']} - Match: {candidate['match_percentage']}%"):
                                    col1, col2 = st.columns(2)
                                    with col1:
                                        st.write("**Contact Information**")
                                        st.write(f"📧 Email: {candidate['email']}")
                                        st.write(f"📞 Phone: {candidate['phone']}")
                            
                                    with col2:
                                        st.write("**Match Summary**")
                                        st.write(candidate['match_summary'])
                            
                                    # Adding percentage allocation for each key role
                                    st.write("**Key Role Percentages**")
                                    if "role_percentages" in candidate:
                                        for role, percentage in candidate["role_percentages"].items():
                                            st.write(f"📊 {role}: {percentage}%")
                                    else:
                                        st.write("No detailed role percentages provided.")
                            
                                    st.write("**Key Strengths**")
                                    for strength in candidate['strengths']:
                                        st.write(f"✅ {strength}")
                            
                                    st.write("**Areas for Improvement**")
                                    for gap in candidate['gaps']:
                                        st.write(f"📌 {gap}")

                        else:
                            st.warning("No matches found.")
                else:
                    st.warning("No resume data available for analysis.")
        else:
            st.warning("No resume files found in the directory.")
    except Exception as e:
        st.error(f"Error: {str(e)}")
else:
    if not job_json:
        st.info("Please upload a job description first.")
    if not st.session_state.directory_path:
        st.info("Please select a directory containing resumes.")
    if not st.session_state.context_submitted:
        st.info("Please submit the manager's context.")
