import streamlit as st
import json
import pandas as pd
import PyPDF2
from langchain.prompts import PromptTemplate
from langchain_openai import ChatOpenAI  
from dotenv import load_dotenv
import io  

load_dotenv()

uploaded_file = st.file_uploader("Upload Job Description", type=['txt', 'pdf'])

job_description = ""
if uploaded_file is not None:

    if uploaded_file.type == "application/pdf":
        pdf_reader = PyPDF2.PdfReader(uploaded_file)
        job_description = "\n".join([page.extract_text() for page in pdf_reader.pages])
    elif uploaded_file.type == "text/plain":
        job_description = uploaded_file.read().decode("utf-8")

prompt_template = """
Extract the following information from the job description:

     "Job_Title": "",
     "Department": "",
     "Location": "",
     "Role_Summary": "",
     "Key_Responsibilties": "",
     "Required_Skills": "",
     "Experience_level": "",
     "Educational_Background": "",
     "Preferred_Qualifications": "",
     "Soft_skills": ""

Job Description:
{job_description}

Ensure the response is in strict JSON format with no extra text, explanations, or line breaks.
Ensure no critical information is missed and identify any missing standard elements.
If certain fields are not explicitly mentioned in the job description, use 'Not specified' for required fields.

"""

prompt = PromptTemplate(input_variables=["job_description"], template=prompt_template)

llm = ChatOpenAI(
    model="gpt-4-turbo-preview",
    temperature=0.1,
)

@st.cache_data
def extract_job_components(description):
    input_messages = [{"role": "user", "content": prompt.format(job_description=description)}]
    response = llm.invoke(input=input_messages)
    content = response.content.strip()

    if not content.startswith("{"):
        start = content.find("{")
        end = content.rfind("}") + 1
        if start != -1 and end != -1:
            content = content[start:end]
    return content


if job_description:
    job_components = extract_job_components(job_description)
    
    try:
        job_json = json.loads(job_components)
    except json.JSONDecodeError as e:
        st.error(f"Error parsing JSON: {e}")
        job_json = {}

    toggle = st.checkbox("Show Raw JSON instead of Table", value=False)

    if not toggle:
        job_data = {
            "Key": ["Job_Title", "Department", "Location", "Role_Summary", "Key_Responsibilties", 
                    "Required_Skills", "Experience_level", "Educational_Background", 
                    "Preferred_Qualifications", "Soft_skills"],
            "Value": [
                job_json.get("Job_Title", "Not specified"),
                job_json.get("Department", "Not specified"),
                job_json.get("Location", "Not specified"),
                job_json.get("Role_Summary", "Not specified"),
                "\n".join(job_json.get("Key_Responsibilties", ["Not specified"])),
                "\n".join(job_json.get("Required_Skills", ["Not specified"])),
                job_json.get("Experience_level", "Not specified"),
                job_json.get("Educational_Background", "Not specified"),
                "\n".join(job_json.get("Preferred_Qualifications", ["Not specified"])),
                "\n".join(job_json.get("Soft_skills", ["Not specified"]))
            ]
        }
        df = pd.DataFrame(job_data)
        st.write("### Job Description:")
        st.dataframe(df)
    else:
        st.write("### Raw JSON Output:")
        st.json(job_json)

    json_str = json.dumps(job_json, indent=4)
    json_bytes = json_str.encode("utf-8")
    st.download_button(
        label="Download JSON",
        data=json_bytes,
        file_name="job_components.json",
        mime="application/json"
    )