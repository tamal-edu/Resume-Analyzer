### iter-7

import streamlit as st
from langchain.chat_models import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.output_parsers import PydanticOutputParser
from langchain_community.document_loaders import (
    PyPDFLoader, Docx2txtLoader, TextLoader,
    UnstructuredPowerPointLoader, UnstructuredHTMLLoader,
    UnstructuredMarkdownLoader
)
from langchain.text_splitter import RecursiveCharacterTextSplitter
from pydantic import BaseModel, Field
from typing import List, Optional, Dict
import json
from datetime import datetime
import os
import tempfile
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

# Enhanced Seniority Level Definition
SENIORITY_LEVELS = {
    'Entry Level': {
        'years': '0-2',
        'responsibilities': 'Basic tasks, Learning environment',
        'supervision': 'Close supervision required'
    },
    'Junior': {
        'years': '2-4',
        'responsibilities': 'Independent tasks, Growing autonomy',
        'supervision': 'Regular supervision'
    },
    'Mid Level': {
        'years': '4-6',
        'responsibilities': 'Complex tasks, Project ownership',
        'supervision': 'Minimal supervision'
    },
    'Senior': {
        'years': '6-10',
        'responsibilities': 'Strategic tasks, Team leadership',
        'supervision': 'Self-directed'
    },
    'Lead': {
        'years': '10+',
        'responsibilities': 'Department leadership, Strategy planning',
        'supervision': 'Leads others'
    },
    'Executive': {
        'years': '15+',
        'responsibilities': 'Organizational leadership, Vision setting',
        'supervision': 'Executive decision-making'
    }
}

class JobDescription(BaseModel):
    title: str
    department: str = Field(default="Not specified")
    location: str = Field(default="Not specified")
    role_summary: str
    key_responsibilities: List[str]
    required_skills: List[str]
    experience_level: float
    educational_background: List[str]
    preferred_qualifications: List[str]
    soft_skills: List[str]

def calculate_quality_score(jd_dict: dict) -> int:
    """Calculate quality score based on completeness and detail level"""
    score = 0
    required_fields = {
        'title': 10,
        'department': 5,
        'location': 5,
        'role_summary': 10,
        'key_responsibilities': 15,
        'required_skills': 15,
        'experience_level': 10,
        'educational_background': 10
    }
    
    for field, points in required_fields.items():
        if field in jd_dict and jd_dict[field] and jd_dict[field] != "Not specified":
            if isinstance(jd_dict[field], list) and len(jd_dict[field]) > 0:
                score += points
            elif isinstance(jd_dict[field], str) and len(jd_dict[field].strip()) > 0:
                score += points
    
    # Bonus points for detailed skills and responsibilities
    if 'required_skills' in jd_dict and len(jd_dict['required_skills']) >= 5:
        score += 5
    if 'key_responsibilities' in jd_dict and len(jd_dict['key_responsibilities']) >= 5:
        score += 5

    return min(score, 100)

class DocumentProcessor:
    SUPPORTED_EXTENSIONS = {
        '.pdf': PyPDFLoader,
        '.docx': Docx2txtLoader,
        '.txt': TextLoader,
        '.pptx': UnstructuredPowerPointLoader,
        '.html': UnstructuredHTMLLoader,
        '.md': UnstructuredMarkdownLoader
    }

    def __init__(self):
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=2000,
            chunk_overlap=200,
            length_function=len,
            #separator="\n",
        )

    def load_document(self, file_path: str) -> str:
        file_extension = Path(file_path).suffix.lower()
        if file_extension not in self.SUPPORTED_EXTENSIONS:
            raise ValueError(f"Unsupported file type: {file_extension}")
        
        loader_class = self.SUPPORTED_EXTENSIONS[file_extension]
        loader = loader_class(file_path)
        
        try:
            documents = loader.load()
            text_chunks = self.text_splitter.split_documents(documents)
            return " ".join([chunk.page_content for chunk in text_chunks])
        except Exception as e:
            raise Exception(f"Error processing document: {str(e)}")

def get_default_prompt():
    return """Analyze the following job description and extract key information in a structured format.
    Ensure no critical information is missed and identify any missing standard elements.
    If certain fields are not explicitly mentioned in the job description, use 'Not specified' for required fields.
    Focus on creating a clear, resume-matching friendly output that captures essential requirements.
    
    Job Description:
    {jd_text}
    
    Source File: {source_file}
    
    Requirements:
    1. Extract all standard JD information according to the schema:
       - Job Title
       - Department
       - Location
       - Role Summary
       - Key Responsibilities
       - Required Skills
       - Experience Level
       - Educational Background
       - Preferred Qualifications
       - Soft Skills
    2. For missing required fields, use 'Not specified'.
    3. Calculate quality score based on completeness and clarity.
    4. List any missing standard elements.
    5. Categorize skills and responsibilities appropriately.
    
    Provide the output in valid JSON format that matches the following schema:
    {format_instructions}
    """

def get_analysis_prompt(custom_template=None):
    template = custom_template if custom_template else get_default_prompt()
    parser = PydanticOutputParser(pydantic_object=JobDescription)
    return ChatPromptTemplate.from_template(template=template), parser

def save_uploaded_file(uploaded_file) -> str:
    try:
        suffix = Path(uploaded_file.name).suffix
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp_file:
            tmp_file.write(uploaded_file.getvalue())
            return tmp_file.name
    except Exception as e:
        st.error(f"Error saving uploaded file: {str(e)}")
        return None
    
def generate_job_description_json(analysis: dict) -> str:
    job_description = {
        "Job Title": analysis["title"],
        "Department": analysis["department"],
        "Location": analysis["location"],
        "Role Summary": analysis["role_summary"],
        "Key Responsibilities": analysis["key_responsibilities"],
        "Required Skills": analysis["required_skills"],
        "Experience Level": analysis["experience_level"],
        "Educational Background": analysis["educational_background"],
        "Preferred Qualifications": analysis["preferred_qualifications"],
        "Soft Skills": analysis["soft_skills"]
    }
    return json.dumps(job_description, indent=4, ensure_ascii=False)

def display_analysis(analysis: dict):
    st.subheader("Job Description Summary")
    
    # Create a tabular format
    job_description_data = [
        ["Job Title", analysis["title"]],
        ["Department", analysis["department"]],
        ["Location", analysis["location"]],
        ["Role Summary", analysis["role_summary"]],
        ["Key Responsibilities", "\n- " + "\n- ".join(analysis["key_responsibilities"])],
        ["Required Skills", "\n- " + "\n- ".join(analysis["required_skills"])],
        ["Experience Level", analysis["experience_level"]],
        ["Educational Background", "\n- " + "\n- ".join(analysis["educational_background"])],
        ["Preferred Qualifications", "\n- " + "\n- ".join(analysis["preferred_qualifications"])],
        ["Soft Skills", "\n- " + "\n- ".join(analysis["soft_skills"])],
    ]

    # Display the tabular format
    st.table(job_description_data)

    st.subheader("Quality Metrics")
    quality_score = analysis['quality_score']
    st.progress(quality_score / 100)
    st.write(f"Quality Score: {quality_score}/100")
    
    if quality_score < 70:
        st.warning("Consider adding more details to improve the job description quality.")
    elif quality_score >= 90:
        st.success("Excellent job description quality!")
    else:
        st.info("Good job description quality. Could be improved with more details.")

    st.subheader("Job Description JSON")
    st.code(generate_job_description_json(analysis), language='json')

def main():
    st.set_page_config(page_title="Enhanced JD Analyzer", layout="wide")
    st.title("Enhanced Job Description Analyzer")
    
    if 'processed_jds' not in st.session_state:
        st.session_state.processed_jds = []
    if 'document_processor' not in st.session_state:
        st.session_state.document_processor = DocumentProcessor()

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        api_key = st.sidebar.text_input("Enter OpenAI API Key", type="password")
        if not api_key:
            st.error("Please enter your OpenAI API key to proceed.")
            st.stop()
    
    llm = ChatOpenAI(
        model="gpt-4o-mini",
        temperature=0.1,
        api_key=api_key
    )
    
    # Prompt Template Selection
    template_option = st.sidebar.radio(
        "Choose Prompt Template:",
        ["Default", "Custom", "From File"]
    )
    
    custom_template = None
    if template_option == "Custom":
        custom_template = st.sidebar.text_area(
            "Enter custom prompt template:",
            value=get_default_prompt(),
            height=300
        )
    elif template_option == "From File":
        template_file = st.sidebar.file_uploader(
            "Upload prompt template file",
            type=['txt']
        )
        if template_file:
            custom_template = template_file.getvalue().decode()
    
    # Seniority Level Override
    st.sidebar.subheader("Seniority Level Settings")
    allow_override = st.sidebar.checkbox("Allow Seniority Level Override")
    if allow_override:
        selected_seniority = st.sidebar.selectbox(
            "Override Seniority Level",
            options=list(SENIORITY_LEVELS.keys())
        )
    
    input_method = st.radio("Choose input method:", ["Text Input", "File Upload"])
    
    jd_text = None
    source_file = "Manual Input"
    
    if input_method == "Text Input":
        jd_text = st.text_area("Paste job description here:", height=300)
    else:
        uploaded_file = st.file_uploader(
            "Upload job description",
            type=['txt', 'pdf', 'docx', 'pptx', 'html', 'md']
        )
        
        if uploaded_file:
            with st.spinner("Processing uploaded file..."):
                try:
                    temp_path = save_uploaded_file(uploaded_file)
                    if temp_path:
                        jd_text = st.session_state.document_processor.load_document(temp_path)
                        source_file = uploaded_file.name
                        with st.expander("Show document preview"):
                            st.text(jd_text[:500] + "..." if len(jd_text) > 500 else jd_text)
                except Exception as e:
                    st.error(f"Error processing file: {str(e)}")
    
    if st.button("Analyze Job Description") and jd_text:
        with st.spinner("Analyzing job description..."):
            prompt, parser = get_analysis_prompt(custom_template)
            messages = prompt.format_messages(
                jd_text=jd_text,
                source_file=source_file,
                format_instructions=parser.get_format_instructions()
                )
            
            try:
                response = llm.invoke(messages)
                analysis = parser.parse(response.content)
                analysis_dict = analysis.model_dump()
                
                # Apply seniority override if enabled
                if 'allow_override' in locals() and allow_override and selected_seniority:
                    analysis_dict['seniority_level'] = selected_seniority
                
                # Calculate quality score
                analysis_dict['quality_score'] = calculate_quality_score(analysis_dict)
                
                # Store processed JD
                st.session_state.processed_jds.append(analysis_dict)
                
                # Display analysis
                display_analysis(analysis_dict)
                
                # Generate and save JSON with pretty formatting
                jd_json = generate_job_description_json(analysis_dict)
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                jd_filename = f"job_description_{timestamp}.json"
                
                # Save JSON file
                with open(jd_filename, 'w', encoding='utf-8') as f:
                    f.write(jd_json)
                
                # Provide download button
                st.download_button(
                    label="Download Job Description",
                    data=jd_json,
                    file_name=jd_filename,
                    mime="application/json"
                )
                
                # Display historical analysis
                if len(st.session_state.processed_jds) > 1:
                    st.subheader("Historical Analysis")
                    with st.expander("View Previously Analyzed JDs"):
                        for idx, hist_jd in enumerate(st.session_state.processed_jds[:-1]):
                            st.write(f"Analysis {idx + 1}: {hist_jd['title']}")
                            if st.button(f"Show Analysis {idx + 1}"):
                                display_analysis(hist_jd)
                
            except Exception as e:
                st.error(f"Error analyzing JD: {str(e)}")
                st.error("Please check if the job description content is valid and try again.")

if __name__ == "__main__":
    main()

"""
Changes Made

Tabular Job Description Display:

The display_analysis() function was added to create a tabular format for displaying the job description details.
A list of lists was used to represent the rows and columns of the table.
The st.table() function was used to render the tabular data.


Tabular Format Implementation:

The job description data was formatted into a list of lists, where each inner list represents a row in the table.
The rows include the following information:

Job Title
Department
Location
Role Summary
Key Responsibilities
Required Skills
Experience Level
Educational Background
Preferred Qualifications
Soft Skills




Formatting Improvements:

The formatting of the list items (responsibilities, skills, etc.) was improved by adding a newline and hyphen before each item.
This makes the tabular display more readable and easier to scan.


Existing Functionality Retained:

The rest of the application's functionality, including the quality score calculation, JSON output, and historical analysis, remains the same as the previous version.



Benefits of the Changes

Improved Readability: The tabular format makes the job description details more easily scannable and comprehensible for the user.
Consistent Presentation: The standardized tabular layout provides a consistent way to display the job description information, regardless of the input.
Seamless Integration: The changes were made without disrupting the existing functionality of the application, ensuring a smooth user experience.

Usage Example
With the updated application, the job description analysis will be displayed in a clear, tabular format by default. Here's an example of how the output might look:


Job Description Summary
┌────────────────────────┬──────────────────────────────────────┐
│ Job Title             │ Software Engineer                    │
│ Department            │ Engineering                         │
│ Location              │ San Francisco, CA                   │
│ Role Summary          │ Develop and maintain web applications│
│ Key Responsibilities  │ - Write clean, efficient code        │
│                       │ - Collaborate with cross-functional  │
│                       │   teams                              │
│                       │ - Participate in code reviews        │
│ Required Skills       │ - Python                             │
│                       │ - JavaScript                         │
│                       │ - React                              │
│ Experience Level      │ 3-5 years                            │
│ Educational Background│ - Bachelor's in Computer Science     │
│                       │ - Master's in Software Engineering   │
│ Preferred Qualifications│- Experience with AWS              │
│                       │- Familiarity with agile methodologies│
│ Soft Skills           │ - Problem-solving                    │
│                       │ - Teamwork                           │
│                       │ - Communication                      │
└────────────────────────┴──────────────────────────────────────┘

Quality Metrics
Quality Score: 90/100
Excellent job description quality!

### EOF-tam-v5 ###
"""
