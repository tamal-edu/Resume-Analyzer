
# iter-3- Enhanced Job Description Analyzer with Resume Matching Preprocessor --Working-Production

import streamlit as st
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import PydanticOutputParser
from langchain_community.document_loaders import (
    PyPDFLoader,
    Docx2txtLoader,
    TextLoader,
    UnstructuredPowerPointLoader,
    UnstructuredHTMLLoader,
    UnstructuredMarkdownLoader
)
from langchain_text_splitters import RecursiveCharacterTextSplitter
from pydantic import BaseModel, Field
from typing import List, Optional, Dict
import json
from datetime import datetime
import os
import tempfile
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

class RequiredSkill(BaseModel):
    skill: str
    importance: str = Field(description="Critical/Important/Nice to have")
    category: str = Field(description="Technical/Soft/Domain")

class Responsibility(BaseModel):
    description: str
    category: str = Field(description="Primary/Secondary")

class ResumeMatchingCriteria(BaseModel):
    """New model for resume matching specific data"""
    must_have_skills: List[str] = Field(description="Skills that are absolutely required")
    preferred_skills: List[str] = Field(description="Skills that are preferred but not mandatory")
    minimum_years_experience: float = Field(description="Minimum years of experience required")
    education_requirements: List[str] = Field(description="List of acceptable education qualifications")
    core_responsibilities: List[str] = Field(description="Key responsibilities for matching")
    industry_knowledge: List[str] = Field(description="Required industry-specific knowledge")
    seniority_level: str = Field(description="Expected level of seniority")

class JobDescription(BaseModel):
    title: str
    department: str = Field(default="Not specified")
    level: str = Field(default="Not specified", description="Entry/Mid/Senior/Lead/Management")
    employment_type: str = Field(default="Not specified", description="Full-time/Part-time/Contract")
    location: str = Field(default="Not specified")
    remote_policy: Optional[str] = None
    required_skills: List[RequiredSkill]
    responsibilities: List[Responsibility]
    required_experience: str
    required_education: Optional[str] = None
    salary_range: Optional[str] = None
    benefits: Optional[List[str]] = None
    company_overview: Optional[str] = None
    additional_notes: Optional[str] = None
    quality_score: int = Field(description="Score from 0-100 indicating JD completeness")
    missing_elements: List[str] = Field(description="List of standard elements missing from JD")
    essence_summary: str = Field(description="Brief capture of JD's core essence")
    source_file: Optional[str] = Field(description="Name of the source file")
    resume_matching_criteria: ResumeMatchingCriteria = Field(description="Preprocessed data for resume matching")

class DocumentProcessor:
    """Handles document loading and processing for various file types"""
    
    SUPPORTED_EXTENSIONS = {
        '.pdf': PyPDFLoader,
        '.docx': Docx2txtLoader,
        '.txt': TextLoader,
        '.pptx': UnstructuredPowerPointLoader,
        '.html': UnstructuredHTMLLoader,
        '.md': UnstructuredMarkdownLoader
    }

    def __init__(self):
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=2000,
            chunk_overlap=200,
            length_function=len,
            is_separator_regex=False,
        )

    def load_document(self, file_path: str) -> str:
        """Load and process a document file"""
        file_extension = Path(file_path).suffix.lower()
        
        if file_extension not in self.SUPPORTED_EXTENSIONS:
            raise ValueError(f"Unsupported file type: {file_extension}")
        
        loader_class = self.SUPPORTED_EXTENSIONS[file_extension]
        loader = loader_class(file_path)
        
        try:
            documents = loader.load()
            text_chunks = self.text_splitter.split_documents(documents)
            combined_text = " ".join([chunk.page_content for chunk in text_chunks])
            return combined_text
        except Exception as e:
            raise Exception(f"Error processing document: {str(e)}")

def get_analysis_prompt():
    template = """Analyze the following job description and extract key information in a structured format.
    Focus on creating a clear, resume-matching friendly output that captures essential requirements.
    
    Job Description:
    {jd_text}
    
    Source File: {source_file}
    
    Requirements:
    1. Extract all standard JD information according to the schema.
    2. For missing required fields, use 'Not specified'.
    3. Create a focused resume_matching_criteria section that includes:
       - Must-have skills (only the most critical ones)
       - Preferred skills (important but not deal-breakers)
       - Minimum years of experience (express as a number)
       - Education requirements (list of acceptable qualifications)
       - Core responsibilities (key duties for matching)
       - Industry knowledge requirements
       - Seniority level
    4. Assign a quality score (0-100) based on completeness and clarity.
    5. List any missing standard elements.
    6. Provide a brief essence capture (core message of the JD).
    7. Categorize skills and responsibilities appropriately.
    
    Provide the output in valid JSON format that matches the following schema:
    {format_instructions}
    """
    
    parser = PydanticOutputParser(pydantic_object=JobDescription)
    prompt = ChatPromptTemplate.from_template(template=template)
    
    return prompt, parser

def save_uploaded_file(uploaded_file) -> str:
    """Save uploaded file to temporary directory and return path"""
    try:
        suffix = Path(uploaded_file.name).suffix
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp_file:
            tmp_file.write(uploaded_file.getvalue())
            return tmp_file.name
    except Exception as e:
        st.error(f"Error saving uploaded file: {str(e)}")
        return None

def generate_resume_matching_json(analysis: dict) -> str:
    """Generate a focused JSON string for resume matching"""
    matching_data = {
        "position": {
            "title": analysis["title"],
            "level": analysis["level"],
            "department": analysis["department"]
        },
        "requirements": {
            "must_have_skills": analysis["resume_matching_criteria"]["must_have_skills"],
            "preferred_skills": analysis["resume_matching_criteria"]["preferred_skills"],
            "minimum_experience": analysis["resume_matching_criteria"]["minimum_years_experience"],
            "education": analysis["resume_matching_criteria"]["education_requirements"]
        },
        "core_responsibilities": analysis["resume_matching_criteria"]["core_responsibilities"],
        "industry_knowledge": analysis["resume_matching_criteria"]["industry_knowledge"],
        "seniority": analysis["resume_matching_criteria"]["seniority_level"]
    }
    return json.dumps(matching_data, indent=2)

def display_analysis(analysis: dict):
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Basic Information")
        if analysis.get('source_file'):
            st.write(f"**Source File:** {Path(analysis['source_file']).name}")
        st.write(f"**Title:** {analysis['title']}")
        st.write(f"**Department:** {analysis['department']}")
        st.write(f"**Level:** {analysis['level']}")
        st.write(f"**Location:** {analysis['location']}")
        
        st.subheader("Resume Matching Criteria")
        st.write("**Must-Have Skills:**")
        for skill in analysis['resume_matching_criteria']['must_have_skills']:
            st.write(f"- {skill}")
        
        st.write("**Core Responsibilities:**")
        for resp in analysis['resume_matching_criteria']['core_responsibilities']:
            st.write(f"- {resp}")

    with col2:
        st.subheader("Matching Summary")
        st.info(f"Seniority Level: {analysis['resume_matching_criteria']['seniority_level']}")
        st.write(f"Minimum Experience: {analysis['resume_matching_criteria']['minimum_years_experience']} years")
        
        st.subheader("Quality Score")
        st.progress(analysis['quality_score'] / 100)
        st.write(f"Score: {analysis['quality_score']}/100")

        # Display the resume matching JSON
        st.subheader("Resume Matching JSON")
        st.code(generate_resume_matching_json(analysis), language='json')

def main():
    st.set_page_config(page_title="JD Analyzer for Resume Matching", layout="wide")
    st.title("Job Description Analyzer for Resume Matching")
    
    if 'processed_jds' not in st.session_state:
        st.session_state.processed_jds = []
    if 'document_processor' not in st.session_state:
        st.session_state.document_processor = DocumentProcessor()

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        api_key = st.sidebar.text_input("Enter OpenAI API Key", type="password")
        if not api_key:
            st.error("Please enter your OpenAI API key to proceed.")
            st.stop()
    
    llm = ChatOpenAI(
        model="gpt-4o-mini",
        temperature=0.1,
        api_key=api_key
    )
    
    input_method = st.radio("Choose input method:", ["Text Input", "File Upload"])
    
    jd_text = None
    source_file = "Manual Input"
    
    if input_method == "Text Input":
        jd_text = st.text_area("Paste job description here:", height=300)
    else:
        uploaded_file = st.file_uploader(
            "Upload job description",
            type=['txt', 'pdf', 'docx', 'pptx', 'html', 'md']
        )
        
        if uploaded_file:
            with st.spinner("Processing uploaded file..."):
                try:
                    temp_path = save_uploaded_file(uploaded_file)
                    if temp_path:
                        jd_text = st.session_state.document_processor.load_document(temp_path)
                        source_file = uploaded_file.name
                        with st.expander("Show document preview"):
                            st.text(jd_text[:500] + "..." if len(jd_text) > 500 else jd_text)
                except Exception as e:
                    st.error(f"Error processing file: {str(e)}")
    
    if st.button("Analyze for Resume Matching") and jd_text:
        with st.spinner("Analyzing job description and preparing resume matching criteria..."):
            prompt, parser = get_analysis_prompt()
            messages = prompt.format_messages(
                jd_text=jd_text,
                source_file=source_file,
                format_instructions=parser.get_format_instructions()
            )
            
            response = llm.invoke(messages)
            try:
                analysis = parser.parse(response.content)
                analysis.source_file = source_file
                analysis_dict = analysis.model_dump()
                
                st.session_state.processed_jds.append(analysis_dict)
                display_analysis(analysis_dict)
                
                # Save the resume matching JSON
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                matching_filename = f"resume_matching_{timestamp}.json"
                
                with open(matching_filename, 'w') as f:
                    json.dump(generate_resume_matching_json(analysis_dict), f, indent=2)
                
                with open(matching_filename, 'r') as f:
                    st.download_button(
                        label="Download Resume Matching Criteria",
                        data=f.read(),
                        file_name=matching_filename,
                        mime="application/json"
                    )
                
            except Exception as e:
                st.error(f"Error analyzing JD: {str(e)}")

if __name__ == "__main__":
    main()


##### iter-2 Working-production

# import streamlit as st
# from langchain_openai import ChatOpenAI
# from langchain_core.prompts import ChatPromptTemplate
# from langchain_core.output_parsers import PydanticOutputParser
# from langchain_community.document_loaders import (
#     PyPDFLoader,
#     Docx2txtLoader,
#     TextLoader,
#     UnstructuredPowerPointLoader,
#     UnstructuredHTMLLoader,
#     UnstructuredMarkdownLoader
# )
# from langchain_text_splitters import RecursiveCharacterTextSplitter
# from pydantic import BaseModel, Field
# from typing import List, Optional, Dict
# import json
# from datetime import datetime
# import os
# import tempfile
# from pathlib import Path
# from dotenv import load_dotenv

# load_dotenv()

# # Pydantic models remain the same
# class RequiredSkill(BaseModel):
#     skill: str
#     importance: str = Field(description="Critical/Important/Nice to have")
#     category: str = Field(description="Technical/Soft/Domain")

# class Responsibility(BaseModel):
#     description: str
#     category: str = Field(description="Primary/Secondary")

# class JobDescription(BaseModel):
#     title: str
#     # Making previously required fields optional with default values
#     department: str = Field(default="Not specified")
#     level: str = Field(default="Not specified", description="Entry/Mid/Senior/Lead/Management")
#     employment_type: str = Field(default="Not specified", description="Full-time/Part-time/Contract")
#     location: str = Field(default="Not specified")
#     remote_policy: Optional[str] = None
#     required_skills: List[RequiredSkill]
#     responsibilities: List[Responsibility]
#     required_experience: str
#     required_education: Optional[str] = None
#     salary_range: Optional[str] = None
#     benefits: Optional[List[str]] = None
#     company_overview: Optional[str] = None
#     additional_notes: Optional[str] = None
#     quality_score: int = Field(description="Score from 0-100 indicating JD completeness")
#     missing_elements: List[str] = Field(description="List of standard elements missing from JD")
#     essence_summary: str = Field(description="Brief capture of JD's core essence")
#     source_file: Optional[str] = Field(description="Name of the source file")

# class DocumentProcessor:
#     """Handles document loading and processing for various file types"""
    
#     SUPPORTED_EXTENSIONS = {
#         '.pdf': PyPDFLoader,
#         '.docx': Docx2txtLoader,
#         '.txt': TextLoader,
#         '.pptx': UnstructuredPowerPointLoader,
#         '.html': UnstructuredHTMLLoader,
#         '.md': UnstructuredMarkdownLoader
#     }

#     def __init__(self):
#         self.text_splitter = RecursiveCharacterTextSplitter(
#             chunk_size=2000,
#             chunk_overlap=200,
#             length_function=len,
#             is_separator_regex=False,
#         )

#     def load_document(self, file_path: str) -> str:
#         """Load and process a document file"""
#         file_extension = Path(file_path).suffix.lower()
        
#         if file_extension not in self.SUPPORTED_EXTENSIONS:
#             raise ValueError(f"Unsupported file type: {file_extension}")
        
#         loader_class = self.SUPPORTED_EXTENSIONS[file_extension]
#         loader = loader_class(file_path)
        
#         try:
#             documents = loader.load()
#             text_chunks = self.text_splitter.split_documents(documents)
#             combined_text = " ".join([chunk.page_content for chunk in text_chunks])
#             return combined_text
#         except Exception as e:
#             raise Exception(f"Error processing document: {str(e)}")

# def init_app():
#     st.set_page_config(page_title="JD Analyzer", layout="wide")
#     st.title("Job Description Analyzer and Summarizer")
    
#     if 'processed_jds' not in st.session_state:
#         st.session_state.processed_jds = []
#     if 'document_processor' not in st.session_state:
#         st.session_state.document_processor = DocumentProcessor()

# def validate_api_key():
#     api_key = os.getenv("OPENAI_API_KEY")
#     if not api_key:
#         api_key = st.sidebar.text_input("Enter OpenAI API Key", type="password")
#         if not api_key:
#             st.error("Please enter your OpenAI API key to proceed.")
#             st.stop()
#     return api_key

# def create_llm(api_key):
#     return ChatOpenAI(
#         model="gpt-4-1106-preview",
#         temperature=0.1,
#         api_key=api_key
#     )

# def get_analysis_prompt():
#     template = """Analyze the following job description and extract key information in a structured format.
#     Ensure no critical information is missed and identify any missing standard elements.
#     If certain fields are not explicitly mentioned in the job description, use 'Not specified' for required fields.
#     Focus on creating a clear, resume-matching friendly output that captures essential requirements.
    
#     Job Description:
#     {jd_text}
    
#     Source File: {source_file}
    
#     Requirements:
#     1. Extract all information according to the specified schema.
#     2. For missing required fields (department, level, employment_type, location), use 'Not specified'.
#     3. Assign a quality score (0-100) based on completeness and clarity.
#     4. List any missing standard elements.
#     5. Provide a brief essence capture (core message of the JD).
#     6. Categorize skills and responsibilities appropriately.
    
#     Provide the output in valid JSON format that matches the following schema:
#     {format_instructions}
#     """
    
#     parser = PydanticOutputParser(pydantic_object=JobDescription)
#     prompt = ChatPromptTemplate.from_template(template=template)
    
#     return prompt, parser

# def save_uploaded_file(uploaded_file) -> str:
#     """Save uploaded file to temporary directory and return path"""
#     try:
#         suffix = Path(uploaded_file.name).suffix
#         with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp_file:
#             tmp_file.write(uploaded_file.getvalue())
#             return tmp_file.name
#     except Exception as e:
#         st.error(f"Error saving uploaded file: {str(e)}")
#         return None

# def analyze_job_description(jd_text: str, source_file: str, llm) -> dict:
#     prompt, parser = get_analysis_prompt()
    
#     messages = prompt.format_messages(
#         jd_text=jd_text,
#         source_file=source_file,
#         format_instructions=parser.get_format_instructions()
#     )
    
#     response = llm.invoke(messages)
#     try:
#         parsed_output = parser.parse(response.content)
#         parsed_output.source_file = source_file
#         return parsed_output.model_dump()
#     except Exception as e:
#         st.error(f"Error parsing JD: {str(e)}")
#         return None

# def display_analysis(analysis: dict):
#     col1, col2 = st.columns(2)
    
#     with col1:
#         st.subheader("Basic Information")
#         if analysis.get('source_file'):
#             st.write(f"**Source File:** {Path(analysis['source_file']).name}")
#         st.write(f"**Title:** {analysis['title']}")
#         st.write(f"**Department:** {analysis['department']}")
#         st.write(f"**Level:** {analysis['level']}")
#         st.write(f"**Location:** {analysis['location']}")
        
#         st.subheader("Quality Assessment")
#         st.progress(analysis['quality_score'] / 100)
#         st.write(f"Quality Score: {analysis['quality_score']}/100")
        
#         if analysis['missing_elements']:
#             st.warning("Missing Elements:")
#             for element in analysis['missing_elements']:
#                 st.write(f"- {element}")
    
#     with col2:
#         st.subheader("Core Essence")
#         st.info(analysis['essence_summary'])
        
#         if analysis['required_skills']:
#             st.subheader("Key Skills")
#             for skill in analysis['required_skills']:
#                 st.write(f"- {skill['skill']} ({skill['importance']}, {skill['category']})")

# def save_analysis(analysis: dict):
#     timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
#     filename = f"jd_analysis_{timestamp}.json"
    
#     with open(filename, 'w') as f:
#         json.dump(analysis, f, indent=2)
    
#     return filename

# def main():
#     init_app()
#     api_key = validate_api_key()
#     llm = create_llm(api_key)
    
#     st.header("Input Job Description")
#     input_method = st.radio(
#         "Choose input method:",
#         ["Text Input", "File Upload"]
#     )
    
#     jd_text = None
#     source_file = "Manual Input"
    
#     if input_method == "Text Input":
#         jd_text = st.text_area("Paste job description here:", height=300)
#     else:
#         uploaded_file = st.file_uploader(
#             "Upload job description",
#             type=['txt', 'pdf', 'docx', 'pptx', 'html', 'md'],
#             help="Supported formats: PDF, Word, TXT, PowerPoint, HTML, Markdown"
#         )
        
#         if uploaded_file:
#             with st.spinner("Processing uploaded file..."):
#                 try:
#                     temp_path = save_uploaded_file(uploaded_file)
#                     if temp_path:
#                         jd_text = st.session_state.document_processor.load_document(temp_path)
#                         source_file = uploaded_file.name
#                         st.success("File processed successfully!")
                        
#                         # Show preview
#                         with st.expander("Show document preview"):
#                             st.text(jd_text[:500] + "..." if len(jd_text) > 500 else jd_text)
#                 except Exception as e:
#                     st.error(f"Error processing file: {str(e)}")
    
#     if st.button("Analyze Job Description") and jd_text:
#         with st.spinner("Analyzing job description..."):
#             analysis = analyze_job_description(jd_text, source_file, llm)
            
#             if analysis:
#                 st.session_state.processed_jds.append(analysis)
#                 display_analysis(analysis)
                
#                 filename = save_analysis(analysis)
#                 st.success(f"Analysis saved to {filename}")
                
#                 with open(filename, 'r') as f:
#                     st.download_button(
#                         label="Download Analysis",
#                         data=f.read(),
#                         file_name=filename,
#                         mime="application/json"
#                     )

# if __name__ == "__main__":
#     main()



################ iter-1
# import streamlit as st
# from langchain_openai import ChatOpenAI
# from langchain_core.prompts import ChatPromptTemplate
# from langchain_core.output_parsers import PydanticOutputParser
# from langchain_community.document_loaders import (
#     PyPDFLoader,
#     Docx2txtLoader,
#     TextLoader,
#     UnstructuredPowerPointLoader,
#     UnstructuredHTMLLoader,
#     UnstructuredMarkdownLoader
# )
# from langchain_text_splitters import RecursiveCharacterTextSplitter
# from pydantic import BaseModel, Field
# from typing import List, Optional, Dict
# import json
# from datetime import datetime
# import os
# import tempfile
# from pathlib import Path
# from dotenv import load_dotenv

# load_dotenv()

# # Pydantic models remain the same
# class RequiredSkill(BaseModel):
#     skill: str
#     importance: str = Field(description="Critical/Important/Nice to have")
#     category: str = Field(description="Technical/Soft/Domain")

# class Responsibility(BaseModel):
#     description: str
#     category: str = Field(description="Primary/Secondary")

# class JobDescription(BaseModel):
#     title: str
#     # Making previously required fields optional with default values
#     department: str = Field(default="Not specified")
#     level: str = Field(default="Not specified", description="Entry/Mid/Senior/Lead/Management")
#     employment_type: str = Field(default="Not specified", description="Full-time/Part-time/Contract")
#     location: str = Field(default="Not specified")
#     remote_policy: Optional[str] = None
#     required_skills: List[RequiredSkill]
#     responsibilities: List[Responsibility]
#     required_experience: str
#     required_education: Optional[str] = None
#     salary_range: Optional[str] = None
#     benefits: Optional[List[str]] = None
#     company_overview: Optional[str] = None
#     additional_notes: Optional[str] = None
#     quality_score: int = Field(description="Score from 0-100 indicating JD completeness")
#     missing_elements: List[str] = Field(description="List of standard elements missing from JD")
#     essence_summary: str = Field(description="Brief capture of JD's core essence")
#     source_file: Optional[str] = Field(description="Name of the source file")

# class DocumentProcessor:
#     """Handles document loading and processing for various file types"""
    
#     SUPPORTED_EXTENSIONS = {
#         '.pdf': PyPDFLoader,
#         '.docx': Docx2txtLoader,
#         '.txt': TextLoader,
#         '.pptx': UnstructuredPowerPointLoader,
#         '.html': UnstructuredHTMLLoader,
#         '.md': UnstructuredMarkdownLoader
#     }

#     def __init__(self):
#         self.text_splitter = RecursiveCharacterTextSplitter(
#             chunk_size=2000,
#             chunk_overlap=200,
#             length_function=len,
#             is_separator_regex=False,
#         )

#     def load_document(self, file_path: str) -> str:
#         """Load and process a document file"""
#         file_extension = Path(file_path).suffix.lower()
        
#         if file_extension not in self.SUPPORTED_EXTENSIONS:
#             raise ValueError(f"Unsupported file type: {file_extension}")
        
#         loader_class = self.SUPPORTED_EXTENSIONS[file_extension]
#         loader = loader_class(file_path)
        
#         try:
#             documents = loader.load()
#             text_chunks = self.text_splitter.split_documents(documents)
#             combined_text = " ".join([chunk.page_content for chunk in text_chunks])
#             return combined_text
#         except Exception as e:
#             raise Exception(f"Error processing document: {str(e)}")

# def init_app():
#     st.set_page_config(page_title="JD Analyzer", layout="wide")
#     st.title("Job Description Analyzer and Summarizer")
    
#     if 'processed_jds' not in st.session_state:
#         st.session_state.processed_jds = []
#     if 'document_processor' not in st.session_state:
#         st.session_state.document_processor = DocumentProcessor()

# def validate_api_key():
#     api_key = os.getenv("OPENAI_API_KEY")
#     if not api_key:
#         api_key = st.sidebar.text_input("Enter OpenAI API Key", type="password")
#         if not api_key:
#             st.error("Please enter your OpenAI API key to proceed.")
#             st.stop()
#     return api_key

# def create_llm(api_key):
#     return ChatOpenAI(
#         model="gpt-4-1106-preview",
#         temperature=0.1,
#         api_key=api_key
#     )

# def get_analysis_prompt():
#     template = """Analyze the following job description and extract key information in a structured format. 
#     Ensure no critical information is missed and identify any missing standard elements.
    
#     Job Description:
#     {jd_text}
    
#     Source File: {source_file}
    
#     Requirements:
#     1. Extract all information according to the specified schema
#     2. Assign a quality score (0-100) based on completeness and clarity
#     3. List any missing standard elements
#     4. Provide a brief essence capture (core message of the JD)
#     5. Categorize skills and responsibilities appropriately
    
#     Provide the output in valid JSON format that matches the following schema:
#     {format_instructions}
#     """
    
#     parser = PydanticOutputParser(pydantic_object=JobDescription)
#     prompt = ChatPromptTemplate.from_template(template=template)
    
#     return prompt, parser

# def save_uploaded_file(uploaded_file) -> str:
#     """Save uploaded file to temporary directory and return path"""
#     try:
#         suffix = Path(uploaded_file.name).suffix
#         with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp_file:
#             tmp_file.write(uploaded_file.getvalue())
#             return tmp_file.name
#     except Exception as e:
#         st.error(f"Error saving uploaded file: {str(e)}")
#         return None

# def analyze_job_description(jd_text: str, source_file: str, llm) -> dict:
#     prompt, parser = get_analysis_prompt()
    
#     messages = prompt.format_messages(
#         jd_text=jd_text,
#         source_file=source_file,
#         format_instructions=parser.get_format_instructions()
#     )
    
#     response = llm.invoke(messages)
#     try:
#         parsed_output = parser.parse(response.content)
#         parsed_output.source_file = source_file
#         return parsed_output.model_dump()
#     except Exception as e:
#         st.error(f"Error parsing JD: {str(e)}")
#         return None

# def display_analysis(analysis: dict):
#     col1, col2 = st.columns(2)
    
#     with col1:
#         st.subheader("Basic Information")
#         if analysis.get('source_file'):
#             st.write(f"**Source File:** {Path(analysis['source_file']).name}")
#         st.write(f"**Title:** {analysis['title']}")
#         st.write(f"**Department:** {analysis['department']}")
#         st.write(f"**Level:** {analysis['level']}")
#         st.write(f"**Location:** {analysis['location']}")
        
#         st.subheader("Quality Assessment")
#         st.progress(analysis['quality_score'] / 100)
#         st.write(f"Quality Score: {analysis['quality_score']}/100")
        
#         if analysis['missing_elements']:
#             st.warning("Missing Elements:")
#             for element in analysis['missing_elements']:
#                 st.write(f"- {element}")
    
#     with col2:
#         st.subheader("Core Essence")
#         st.info(analysis['essence_summary'])
        
#         if analysis['required_skills']:
#             st.subheader("Key Skills")
#             for skill in analysis['required_skills']:
#                 st.write(f"- {skill['skill']} ({skill['importance']}, {skill['category']})")

# def save_analysis(analysis: dict):
#     timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
#     filename = f"jd_analysis_{timestamp}.json"
    
#     with open(filename, 'w') as f:
#         json.dump(analysis, f, indent=2)
    
#     return filename

# def main():
#     init_app()
#     api_key = validate_api_key()
#     llm = create_llm(api_key)
    
#     st.header("Input Job Description")
#     input_method = st.radio(
#         "Choose input method:",
#         ["Text Input", "File Upload"]
#     )
    
#     jd_text = None
#     source_file = "Manual Input"
    
#     if input_method == "Text Input":
#         jd_text = st.text_area("Paste job description here:", height=300)
#     else:
#         uploaded_file = st.file_uploader(
#             "Upload job description",
#             type=['txt', 'pdf', 'docx', 'pptx', 'html', 'md'],
#             help="Supported formats: PDF, Word, TXT, PowerPoint, HTML, Markdown"
#         )
        
#         if uploaded_file:
#             with st.spinner("Processing uploaded file..."):
#                 try:
#                     temp_path = save_uploaded_file(uploaded_file)
#                     if temp_path:
#                         jd_text = st.session_state.document_processor.load_document(temp_path)
#                         source_file = uploaded_file.name
#                         st.success("File processed successfully!")
                        
#                         # Show preview
#                         with st.expander("Show document preview"):
#                             st.text(jd_text[:500] + "..." if len(jd_text) > 500 else jd_text)
#                 except Exception as e:
#                     st.error(f"Error processing file: {str(e)}")
    
#     if st.button("Analyze Job Description") and jd_text:
#         with st.spinner("Analyzing job description..."):
#             analysis = analyze_job_description(jd_text, source_file, llm)
            
#             if analysis:
#                 st.session_state.processed_jds.append(analysis)
#                 display_analysis(analysis)
                
#                 filename = save_analysis(analysis)
#                 st.success(f"Analysis saved to {filename}")
                
#                 with open(filename, 'r') as f:
#                     st.download_button(
#                         label="Download Analysis",
#                         data=f.read(),
#                         file_name=filename,
#                         mime="application/json"
#                     )

# if __name__ == "__main__":
#     main()
